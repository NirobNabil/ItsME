
export default (this || window).Two;
